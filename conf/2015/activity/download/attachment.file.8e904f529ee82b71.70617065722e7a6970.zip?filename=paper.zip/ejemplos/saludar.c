#include <stdio.h>

int main(void) {
    char cadena[200];
    printf("Hola mundo\n");
}