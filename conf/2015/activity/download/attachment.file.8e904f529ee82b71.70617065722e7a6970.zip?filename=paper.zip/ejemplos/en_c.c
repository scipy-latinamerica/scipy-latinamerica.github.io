#include <stdio.h>

int main(void) {
    char cadena[200];
    fgets(stdin, 50, cadena);
}